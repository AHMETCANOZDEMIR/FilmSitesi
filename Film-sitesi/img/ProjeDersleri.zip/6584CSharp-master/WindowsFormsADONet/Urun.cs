﻿namespace WindowsFormsADONet
{
    public class Urun
    {
        public int Id { get; set; }
        public string UrunAdi { get; set; }
        public decimal UrunFiyati { get; set; }
        public int StokMiktari { get; set; }
    }
}
