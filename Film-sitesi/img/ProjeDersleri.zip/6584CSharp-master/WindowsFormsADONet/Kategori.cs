﻿namespace WindowsFormsADONet
{
    public class Kategori
    {
        public int Id { get; set; }
        public string KategoriAdi { get; set; }
    }
}
