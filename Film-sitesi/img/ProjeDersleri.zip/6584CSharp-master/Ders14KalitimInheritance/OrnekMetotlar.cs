﻿namespace Ders14KalitimInheritance
{
    internal class OrnekMetotlar
    {
        public void OrnekMetot()
        {
            Console.WriteLine("Örnek Metot Çalıştı");
        }
        public void Ekle()
        {
            Console.WriteLine("Kayıt Veritabanına Eklendi!");
        }
        public void Guncelle()
        {
            Console.WriteLine("Kayıt Güncelendi!");
        }
        public void Sil()
        {
            Console.WriteLine("Kayıt Silindi!");
        }
    }
}
