﻿namespace Ders09ErisimBelirleyiciler
{
    public class Kullanici
    {
        public string Adi;
        internal string Soyadi;
        private string Telefon;
        protected string Email;
        string KullaniciAdi;
        string Sifre;
    }
}
