﻿namespace MVCEgitim.Models
{
    public class KullaniciSayfasiViewModel
    {
        public Kullanici Kullanici { get; set; }
        public Adres Adres { get; set; }
    }
}