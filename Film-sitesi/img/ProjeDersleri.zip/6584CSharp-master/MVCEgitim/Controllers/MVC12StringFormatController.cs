﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MVCEgitim.Controllers
{
    public class MVC12StringFormatController : Controller
    {
        // GET: MVC12StringFormat
        public ActionResult Index()
        {
            return View();
        }
    }
}