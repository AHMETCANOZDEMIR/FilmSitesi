﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MVCEgitim.Controllers
{
    public class MVC06SectionController : Controller
    {
        // GET: MVC06Section
        public ActionResult Index()
        {
            return View();
        }
    }
}