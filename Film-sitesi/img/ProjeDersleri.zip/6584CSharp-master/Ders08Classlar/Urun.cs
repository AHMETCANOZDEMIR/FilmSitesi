﻿namespace Ders08Classlar
{
    internal class Urun
    {
        internal int Id;
        internal string Adi;
        internal decimal Fiyati;
        internal string UrunAciklamasi;
        internal string Markasi;
    }
}
