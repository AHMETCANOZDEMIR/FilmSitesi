﻿
namespace Ders08Classlar
{
    internal class Kategori
    {
        internal int Id;
        internal string KatgoriAdi;
    }
}
